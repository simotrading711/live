# مباشر سبورت — مشروع Android

تطبيق أندرويد بسيط باللغة العربية يعرض دليلاً لمصادر الرياضة المجانية والرسمية، مع البحث والتصنيف حسب نوع الرياضة. التطبيق لا يضم قنوات مقرصنة ولا يستضيف بث الفيديو؛ الروابط تفتح مواقع الجهات الرسمية.

## ما يحتويه المشروع
- مشروع Android Studio باستخدام Java وWebView.
- واجهة عربية RTL متجاوبة.
- بحث وتصنيفات: كرة القدم، رياضات متنوعة، المغرب.
- روابط SNRT Live وFIFA+ وRed Bull TV وYouTube الرسمي وOlympics وCAF.
- إذن الإنترنت فقط؛ لا تسجيل دخول ولا جمع بيانات من داخل التطبيق.

## إنشاء APK
يلزم كمبيوتر يعمل بنظام Windows أو macOS أو Linux، مع Android Studio وAndroid SDK.

1. فك ضغط `MubasherSportAndroid.zip`.
2. افتح Android Studio واختر **Open** ثم اختر مجلد `MubasherSportAndroid` الذي يحتوي على `settings.gradle`.
3. وافق على مزامنة Gradle، وثبّت أي Android SDK يطلبه البرنامج.
4. من القائمة اختر **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. بعد انتهاء البناء اضغط رابط **locate** الذي يظهر، أو ابحث عن الملف هنا:
   `app/build/outputs/apk/debug/app-debug.apk`
6. انقل `app-debug.apk` إلى هاتفك وافتحه للتثبيت. قد يطلب Android السماح بالتثبيت من هذا المصدر.

## تشغيل التطبيق للاختبار
وصّل هاتف Android مع تفعيل USB debugging، ثم اضغط **Run** في Android Studio، أو استخدم المحاكي.

## ملاحظات مهمة
- هذا الأرشيف هو **مصدر المشروع** وليس ملف APK مبنيًا.
- بيئة إنشاء الملفات هنا لا تحتوي على Android SDK/عملية توقيع وبناء موثقة؛ لذلك لم أرفق APK غير مبني.
- توفر المباريات يتغير حسب الدولة وحقوق البث. الروابط الرسمية قد تعرض أحداثًا مختارة أو ملخصات فقط.
- قبل نشر التطبيق في متجر Google Play، راجع سياسات المتجر، واستخدم أيقونة واسمًا تملك حق استخدامهما.
- روابط Android الرسمية: https://developer.android.com/studio/projects/create-project و https://developer.android.com/studio/run
